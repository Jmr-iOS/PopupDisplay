//
//  AnotherViewController.swift
//  CustomDialogBox
//
//  Created by Shubham Singh on 01/04/20.
//  Copyright © 2020 Shubham Singh. All rights reserved.
//

import UIKit


class AnotherViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
}
